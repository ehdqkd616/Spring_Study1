package org.zerock.dao;

public interface PointDAO {

	void updatePoint(String sender, int point);

}
