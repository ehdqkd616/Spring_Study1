package org.zerock.dao;

import org.zerock.vo.MessageVO;

public interface MessageDAO {

	void create(MessageVO vo);
	
}
