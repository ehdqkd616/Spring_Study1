package org.zerock.service;

import org.zerock.vo.AdminVO;

public interface AdminService {

	AdminVO admin_Login(String admin_id);

}
