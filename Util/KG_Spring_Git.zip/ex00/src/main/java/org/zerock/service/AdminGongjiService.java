package org.zerock.service;

import org.zerock.vo.GongjiVO;

public interface AdminGongjiService {

	void insertG(GongjiVO g);

}
