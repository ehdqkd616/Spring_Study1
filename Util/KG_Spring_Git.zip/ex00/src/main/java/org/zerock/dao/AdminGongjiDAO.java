package org.zerock.dao;

import org.zerock.vo.GongjiVO;

public interface AdminGongjiDAO {

	void insertG(GongjiVO g);

}
